import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import api from "../../../config/api";
import { FileManager, Folder } from "../../../components/FileManager";
import { useNavigate } from 'react-router-dom';

interface File {
  id: string;
  name: string;
  size?: number;
  type?: string;
  isSelected?: boolean;
}

const Attachments: React.FC = () => {
  const navigate = useNavigate();
  const [companyInfo, setCompanyInfo] = useState({
    company_title: "",
    origin_country_flag_svg: "",
    rating: "",
    company_type: "",
    status: "",
    origin_country: "",
    partner_id: "",
  });

  useEffect(() => {
    const fetchCompanyInfo = async () => {
      try {
        const res = await fetch("/api/company-informations"); // Replace with your actual API
        const data = await res.json();
        setCompanyInfo(data);
      } catch (error) {
        console.error("Error fetching company info:", error);
      }
    };

    fetchCompanyInfo();
  }, []);

  const [countries, setCountries] = useState([]);
  useEffect(() => {
    api
      .get("/api/countries")
      .then((res) => {
        setCountries(res.data);
      })
      .catch((err) => console.error("Failed to fetch countries:", err))
      .finally(() => setLoading(false));
  }, []);

  const getCountryById = (id) => countries.find((c) => c.id === id);

  const { id } = useParams();
  const [partner, setPartner] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!id || countries.length === 0) return;
    const fetchPartner = async () => {
      try {
        setLoading(true);
        setError(null);
        const response = await api.get(`/api/partner/${id}`);
        setPartner(response.data);
        console.log("Partner data:", response.data);

        const rawCountryId = response.data.data.partner_overview?.hq_country;
        const countryId = rawCountryId ? parseInt(rawCountryId, 10) : null;
        const country = countryId ? getCountryById(countryId) : null;

        setCompanyInfo((prev) => ({
          ...prev,
          company_title: response.data.data.partner_overview?.reg_name || "",
          rating: response.data.data.partner_overview?.rating || "",
          company_type: response.data.data.partner_overview?.company_type || "",
          origin_country: country?.name || "",
          origin_country_flag_svg: country?.svg_icon_url || "",
          status: Number(response.data.data.partnership_structure?.status) === 1 ? "Active" : "Inactive",
          partner_id: response.data.data.partner_id || "",
        }));
      } catch (err) {
        console.error("Failed to fetch partner:", err);
        setError(err);
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchPartner();
    }
  }, [id, countries]);

  const fetchFoldersApi = async (): Promise<Folder[]> => {
    console.log("Calling API to fetch folders...");

    try {
      const response = await api.get(`/api/partners/${id}/folders`);

      // Axios automatically handles JSON parsing.
      // Your Laravel API structure has the actual data inside response.data.data
      // and success/message in response.data.success/message.

      const responseData = response.data;

      // Check if the API returned success: true and data (which should be an array)
      if (!responseData.success || !Array.isArray(responseData.data)) {
        const apiErrorMessage =
          responseData.message ||
          "API returned success: false or data is not an array";
        console.error(
          "API indicated failure fetching folders:",
          apiErrorMessage,
          responseData
        );
        // Throw an error with the message from the API if available
        throw new Error(apiErrorMessage);
      }

      console.log("Folders fetched successfully via API:", responseData.data);

      // Return the array of folder objects from the API response
      // Ensure the structure matches your Folder interface { id, name, size?, ... }
      return responseData.data as Folder[];
    } catch (error: any) {
      console.error("Error during API call to fetch folders:", error);

      let userMessage = "Failed to load folders. Please try again.";

      // Check if it's an Axios error and has a response from the server
      if (axios.isAxiosError(error) && error.response) {
        // Server responded with a status code outside the 2xx range
        const serverError = error.response.data;
        if (serverError.message) {
          userMessage = serverError.message;
        } else if (serverError.errors) {
          // Handle validation errors (less likely for fetch, but good to include)
          userMessage =
            "Server responded with errors: " +
            JSON.stringify(serverError.errors);
        } else {
          userMessage = `Server error: ${error.response.status}`;
        }
        console.error("Server Error Details:", serverError);
      } else if (error instanceof Error) {
        // A client-side error occurred (e.g., network error, or the error thrown above)
        userMessage = `Request failed: ${error.message}`;
      }

      // Re-throw a new Error with a user-friendly message
      throw new Error(userMessage);
    }
  };

  const createFolderApi = async (name: string): Promise<Folder> => {
    console.log("Calling API to create folder:", name);

    try {
      const partnerId = localStorage.getItem("partner_id");
      const response = await api.post("/api/folders", {
        name: name,
        partner_id: partnerId,
      });

      const responseData = response.data;

      // Check if the API returned success: true and data
      if (!responseData.success || !responseData.data) {
        const apiErrorMessage =
          responseData.message || "API returned success: false";
        console.error(
          "API indicated failure creating folder:",
          apiErrorMessage,
          responseData
        );
        // Throw an error with the message from the API if available
        throw new Error(apiErrorMessage);
      }

      console.log("Folder created successfully via API:", responseData.data);

      return responseData.data as Folder;
    } catch (error: any) {
      console.error("Error during API call to create folder:", error);

      let userMessage = "Failed to create folder. Please try again.";

      // Check if it's an Axios error and has a response from the server
      if (axios.isAxiosError(error) && error.response) {
        // Server responded with a status code outside the 2xx range
        const serverError = error.response.data;
        if (serverError.message) {
          userMessage = serverError.message;
        } else if (serverError.errors) {
          // Handle validation errors specifically
          // You might want to format these errors more nicely for the user
          userMessage =
            "Validation failed: " + JSON.stringify(serverError.errors);
        } else {
          userMessage = `Server error: ${error.response.status}`;
        }
        console.error("Server Error Details:", serverError);
      } else if (error instanceof Error) {
        // A client-side error occurred (e.g., network error, or the error thrown above)
        userMessage = `Request failed: ${error.message}`;
      }

      // Re-throw a new Error with a user-friendly message
      throw new Error(userMessage);
    }
  };

  const renameFolderApi = async (
    id: string,
    newName: string
  ): Promise<Folder> => {
    console.log(`Calling API to rename folder ${id} to ${newName}`);
    try {
      // Use your configured axios instance for the PUT request
      const response = await api.put(`/api/folders/${id}`, { name: newName });

      const responseData = response.data;

      // Check if the API returned success: true and data
      if (!responseData.success || !responseData.data) {
        const apiErrorMessage =
          responseData.message || "API returned failure renaming folder";
        console.error(
          "API indicated failure renaming folder:",
          apiErrorMessage,
          responseData
        );
        throw new Error(apiErrorMessage);
      }

      console.log("Folder renamed successfully via API:", responseData.data);

      // Return the updated folder object from the API response
      return responseData.data as Folder;
    } catch (error: any) {
      console.error("Error during API call to rename folder:", error);

      let userMessage = "Failed to rename folder. Please try again.";

      if (axios.isAxiosError(error) && error.response) {
        const serverError = error.response.data;
        if (serverError.message) {
          userMessage = serverError.message;
        } else if (serverError.errors) {
          userMessage =
            "Validation failed: " + JSON.stringify(serverError.errors);
        } else {
          userMessage = `Server error: ${error.response.status}`;
        }
        console.error("Server Error Details:", serverError);
      } else if (error instanceof Error) {
        userMessage = `Request failed: ${error.message}`;
      }

      throw new Error(userMessage);
    }
  };

  const deleteFolderApi = async (id: string): Promise<void> => {
    console.log(`Calling API to delete folder ${id}`);
    try {
      // Use your configured axios instance for the DELETE request
      const response = await api.delete(`/api/folders/${id}`);

      const responseData = response.data;

      // Check if the API returned success: true
      if (!responseData.success) {
        const apiErrorMessage =
          responseData.message || "API returned failure deleting folder";
        console.error(
          "API indicated failure deleting folder:",
          apiErrorMessage,
          responseData
        );
        throw new Error(apiErrorMessage);
      }

      console.log("Folder deleted successfully via API:", responseData);

      // No data is expected back for a successful deletion, so return void
      return;
    } catch (error: any) {
      console.error("Error during API call to delete folder:", error);

      let userMessage = "Failed to delete folder. Please try again.";

      if (axios.isAxiosError(error) && error.response) {
        const serverError = error.response.data;
        if (serverError.message) {
          userMessage = serverError.message;
        } else if (serverError.errors) {
          // Validation errors are less likely for delete, but possible
          userMessage =
            "Server responded with errors: " +
            JSON.stringify(serverError.errors);
        } else {
          userMessage = `Server error: ${error.response.status}`;
        }
        console.error("Server Error Details:", serverError);
      } else if (error instanceof Error) {
        userMessage = `Request failed: ${error.message}`;
      }

      throw new Error(userMessage);
    }
  };

  return (
    // Main div start
    <div className="ml-3 font-poppins">
      {/* The div with 3 columns start */}

      {/* Top Header div Start */}
      <div className=" flex w-full mt-[30px]">
        {/* Left Logo Div start  */}
        <div className="w-[1019px] h-[180px]">
          <div className="flex justify-start items-center flex-row gap-[22px] w-[1019px]">
            <svg
              width="180"
              height="180"
              viewBox="0 0 180 180"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <rect width="180" height="180" rx="90" fill="#004831" />
              <path
                d="M145.335 100.827C137.146 131.388 105.733 149.525 75.1717 141.336C44.6107 133.147 26.4744 101.734 34.6632 71.1728C42.852 40.6118 74.265 22.4755 104.826 30.6643C135.387 38.8531 153.523 70.2661 145.335 100.827Z"
                stroke="white"
                strokeWidth="3"
              />
              <path
                d="M61.963 37.4504L138.564 57.9755L118.039 134.576L41.4379 114.051L61.963 37.4504Z"
                stroke="white"
                strokeWidth="3"
              />
              <mask id="path-4-inside-1_180_30749" fill="white">
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M140.144 57.06L79.4043 125.556L61.0508 35.8672"
                />
              </mask>
              <path
                d="M79.4043 125.556L76.4652 126.158L77.6681 132.036L81.6489 127.547L79.4043 125.556ZM137.899 55.0696L77.1597 123.566L81.6489 127.547L142.388 59.0505L137.899 55.0696ZM82.3434 124.955L63.9899 35.2657L58.1117 36.4686L76.4652 126.158L82.3434 124.955Z"
                fill="white"
                mask="url(#path-4-inside-1_180_30749)"
              />
            </svg>

            <div className="flex justify-start items-start flex-col gap-[13px] w-[520px]">
              <div className="flex self-stretch justify-start items-center flex-row gap-[19px]">
                <p className="text-[rgba(0,0,0,0.88)] text-2xl font-semibold leading-8">
                  {companyInfo?.company_title || "N/A"}
                </p>
                <div className="flex justify-center items-center flex-row gap-2 py-1 px-2 bg-[#0C5577] rounded-[36px]">
                  <svg
                    width="8"
                    height="9"
                    viewBox="0 0 8 9"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M8 4.5C8 6.70914 6.20914 8.5 4 8.5C1.79086 8.5 0 6.70914 0 4.5C0 2.29086 1.79086 0.5 4 0.5C6.20914 0.5 8 2.29086 8 4.5Z"
                      fill="white"
                    />
                  </svg>
                  <span className="text-[#FFFFFF] text-xs font-medium leading-[1.4]">
                    {companyInfo?.status || "N/A"}
                  </span>
                </div>
              </div>

              <div className="flex justify-start items-start flex-col gap-4 w-[344px]">
                <div className="flex justify-start items-center flex-row gap-[17px]">
                  <div className="text-[#727272] text-sm font-medium leading-5">
                    HQ / Origin Country
                  </div>
                  <div className="flex justify-start items-center flex-row gap-[8.67px]">
                    {companyInfo?.origin_country_flag_svg ? (
                      <img
                        src={companyInfo.origin_country_flag_svg}
                        alt="flag"
                        className="w-[26px] h-[26px] rounded-full bg-gray-200 text-gray-800 text-[10px] flex items-center justify-center"
                      />
                    ) : (
                      <span className="w-[26px] h-[26px] rounded-full bg-gray-200 text-gray-800 text-[10px] flex items-center justify-center">
                        n/a
                      </span>
                    )}
                    <span className="text-[#30313D] text-sm font-semibold leading-[31.78px]">
                      {companyInfo?.origin_country || "N/A"}
                    </span>
                  </div>
                </div>

                <div className="flex self-stretch justify-start items-center flex-row gap-[49px]">
                  <div className="text-[#727272] text-sm font-medium leading-5">
                    Company Type
                  </div>
                  <span className="text-[#30313D] text-sm font-semibold leading-5">
                    {companyInfo?.company_type || "N/A"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Left Logo Div End  */}

        <div
          className="flex justify-between items-end flex-col h-[40px] mt-[80px] mr-[50px]"
        >
          <span className="text-[#838383] text-sm font-medium leading-[18.86px]">
            Partner ID
          </span>
          <div
            className="flex justify-start items-end flex-row gap-2.5 w-[89px]"
          >
            <span className="text-[#064771] text-sm font-semibold leading-[15px] text-nowrap mt-[-20px] ml-auto text-right block">
              {companyInfo?.partner_id || "N/A"}
            </span>
          </div>
        </div>

        <div className="mt-[80px] mr-[52px] ml-[-30px]">
          <svg
            width="2"
            height="44"
            viewBox="0 0 2 44"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M1 1V43"
              stroke="#94989C"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>

        {/* Right Banner Div Start */}
        <div className="h-[180px] w-[245px] ml-[12px] text-nowrap">
          <div
            className="flex justify-center items-center flex-row gap-[4px]  pr-2 bg-[#064771] rounded-[5px] w-[245px] h-[180px]"
            style={{ width: "245px" }}
          >
            <div className="flex justify-between items-center flex-col gap-1.5 h-[158px]">
              <div className="flex justify-start items-end flex-col gap-[29px] h-[158px]">
                <div
                  className="flex justify-center items-end flex-col gap-1.5 w-[202px]"
                  style={{ width: "202px" }}
                >
                  <div className="flex self-stretch justify-between items-center flex-row gap-[107px]">
                    <div className="flex justify-start items-end flex-row gap-[7.1049323081970215px] h-[24px]">
                      <button className="flex items-center gap-1 py-1 px-2 bg-[#F1FBFF] border border-[#064771] rounded-full w-[57px] h-6">
                        <svg
                          width="15"
                          height="16"
                          viewBox="0 0 15 16"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M5.50127 7.99966C5.50127 9.09163 4.61605 9.97686 3.52407 9.97686C2.4321 9.97686 1.54688 9.09163 1.54688 7.99966C1.54688 6.90769 2.4321 6.02246 3.52407 6.02246C4.61605 6.02246 5.50127 6.90769 5.50127 7.99966Z"
                            stroke="#064771"
                            strokeWidth="1.2"
                          />
                          <path
                            d="M9.4544 3.6499L5.5 6.41798"
                            stroke="#064771"
                            strokeWidth="1.2"
                            strokeLinecap="round"
                          />
                          <path
                            d="M9.4544 12.3511L5.5 9.58301"
                            stroke="#064771"
                            strokeWidth="1.2"
                            strokeLinecap="round"
                          />
                          <path
                            d="M13.4114 13.1403C13.4114 14.2323 12.5262 15.1175 11.4342 15.1175C10.3423 15.1175 9.45703 14.2323 9.45703 13.1403C9.45703 12.0483 10.3423 11.1631 11.4342 11.1631C12.5262 11.1631 13.4114 12.0483 13.4114 13.1403Z"
                            stroke="#064771"
                            strokeWidth="1.2"
                          />
                          <path
                            d="M13.4114 2.85952C13.4114 3.9515 12.5262 4.83672 11.4342 4.83672C10.3423 4.83672 9.45703 3.9515 9.45703 2.85952C9.45703 1.76755 10.3423 0.882324 11.4342 0.882324C12.5262 0.882324 13.4114 1.76755 13.4114 2.85952Z"
                            stroke="#064771"
                            strokeWidth="1.2"
                          />
                        </svg>

                        <span className="text-[#064771] text-[12px] text-nowrap">
                          Share
                        </span>
                      </button>
                    </div>
                    <span className="text-[#FFFFFF] leading-[12.788783073425293px] ml-[-26px]">
                      Partner ID
                    </span>
                  </div>
                </div>
                <div className="flex justify-start items-end flex-col gap-[33px] h-[105px] mt-[-10px]">
                  <div className="flex justify-start items-end flex-col gap-3">
                    <div
                      className="flex justify-start items-center flex-row gap-[10.231026649475098px] w-[179px]"
                      style={{ width: "179px" }}
                    >
                      <svg
                        width="25"
                        height="27"
                        viewBox="0 0 25 27"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          fillRule="evenodd"
                          clipRule="evenodd"
                          d="M1.54886 0C0.945866 0 0.457031 0.549475 0.457031 1.22727C0.457031 1.90507 0.945866 2.45455 1.54886 2.45455H2.88005L6.77158 19.9517C5.62441 20.5244 4.82436 21.8162 4.82436 23.3182C4.82436 25.3517 6.29085 27 8.09985 27C9.90885 27 11.3753 25.3517 11.3753 23.3182C11.3753 22.8879 11.3096 22.4748 11.189 22.0909H15.929C15.8084 22.4748 15.7427 22.8879 15.7427 23.3182C15.7427 25.3517 17.2091 27 19.0182 27C20.8272 27 22.2937 25.3517 22.2937 23.3182C22.2937 21.2847 20.8272 19.6364 19.0182 19.6364H8.95233L8.40642 17.1818H19.0182C21.2719 17.1818 22.6233 15.5813 23.3732 13.8141C24.106 12.087 24.361 10.023 24.45 8.52179C24.5738 6.43108 23.0364 4.90909 21.3341 4.90909H5.67684L4.99852 1.85923C4.75549 0.766542 3.88206 0 2.88005 0H1.54886ZM19.0182 14.7273H7.8605L6.22275 7.36364H21.3341C21.9379 7.36364 22.3005 7.86283 22.2712 8.35868C22.1882 9.75952 21.9558 11.4527 21.4023 12.7574C20.8658 14.0217 20.1319 14.7273 19.0182 14.7273ZM19.0182 24.5378C18.4189 24.5378 17.9331 23.9918 17.9331 23.3182C17.9331 22.6445 18.4189 22.0985 19.0182 22.0985C19.6175 22.0985 20.1032 22.6445 20.1032 23.3182C20.1032 23.9918 19.6175 24.5378 19.0182 24.5378ZM7.01476 23.3182C7.01476 23.9918 7.50057 24.5378 8.09985 24.5378C8.69914 24.5378 9.18495 23.9918 9.18495 23.3182C9.18495 22.6445 8.69914 22.0985 8.09985 22.0985C7.50057 22.0985 7.01476 22.6445 7.01476 23.3182Z"
                          fill="#F9F8FA"
                        />
                      </svg>
                      <p className="text-[#FFFFFF] text-[28.646873474121094px] font-semibold leading-[30.69308090209961px]">
                        {companyInfo?.partner_id || "N/A"}
                      </p>
                    </div>
                    <div className="flex justify-start items-start flex-row gap-1.5">
                      <span className="text-[#AFAFAF] text-sm leading-[18.860000610351562px]">
                        Last Release
                      </span>
                      <span className="text-[#FFFFFF] text-sm font-medium leading-[10px] mt-[5px]">
                        February 2025
                      </span>
                    </div>
                  </div>
                  <button
                    className="flex justify-start items-center flex-row gap-1.5 w-[202px] h-[23px]"
                    style={{ width: "202px" }}
                  >
                    <div
                      className="flex justify-start items-end flex-row gap-[7.1049323081970215px] w-[114px] h-[24px]"
                      style={{ width: "114px" }}
                    >
                      <div className="flex justify-center items-center flex-row gap-[3.044971227645874px] py-[3.5524661540985107px] px-[5.647058963775635px] bg-[#F1FBFF] border-solid border-[#064771] border-[0.3529411852359772px] rounded-[35.16731643676758px] h-[24px]">
                        <svg
                          width="15"
                          height="15"
                          viewBox="0 0 15 15"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M10.6272 10.8206C12.5558 8.89194 12.5558 5.76138 10.6272 3.83272C8.6985 1.90407 5.56793 1.90407 3.63928 3.83272C1.71062 5.76138 1.71062 8.89194 3.63928 10.8206"
                            stroke="#064771"
                            strokeWidth="0.988235"
                            strokeMiterlimit="10"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                          <path
                            d="M7.13499 8.02268L7.13497 13.7527"
                            stroke="#064771"
                            strokeWidth="0.988235"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                          <path
                            d="M5.44517 12.6265L7.13274 14.314L8.82031 12.6265"
                            stroke="#064771"
                            strokeWidth="0.988235"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>

                        <span className="text-[#064771] text-[12px] text-nowrap">
                          Download PDF
                        </span>
                      </div>
                    </div>
                    <button className="flex justify-start items-end flex-row gap-[7.1049323081970215px] h-[24px]">
                      <div
                        className="flex justify-center items-center flex-row gap-[3.044971227645874px] py-[3.5524661540985107px] px-[5.647058963775635px] bg-[#FFFFFF] rounded-[35.16731643676758px] w-[82px] h-[24px]"
                        style={{ width: "82px" }}
                      >
                        <svg
                          width="13"
                          height="13"
                          viewBox="0 0 13 13"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M2.2437 5.87325C2.58773 3.53533 4.76188 1.91897 7.0998 2.263C7.89745 2.38037 8.6457 2.72072 9.25836 3.24484L8.70684 3.79637C8.52198 3.98127 8.52203 4.28103 8.70695 4.46588C8.79569 4.55461 8.91606 4.60447 9.04155 4.60449H11.2127C11.4741 4.60449 11.6861 4.39254 11.6861 4.13108V1.95998C11.686 1.69852 11.474 1.48661 11.2125 1.48665C11.0871 1.48668 10.9667 1.53654 10.8779 1.62526L10.2625 2.2407C7.91549 0.148595 4.31689 0.355198 2.22479 2.70217C1.48362 3.53362 1.00264 4.56424 0.841439 5.66636C0.777882 6.05708 1.04309 6.42535 1.4338 6.48891C1.46899 6.49463 1.50454 6.49772 1.5402 6.49816C1.89767 6.4943 2.19772 6.22776 2.2437 5.87325Z"
                            fill="#064771"
                          />
                          <path
                            d="M11.4193 6.50146C11.0618 6.50533 10.7617 6.77187 10.7158 7.12638C10.3717 9.4643 8.19759 11.0807 5.85967 10.7366C5.06202 10.6193 4.31376 10.2789 3.7011 9.75481L4.25262 9.20328C4.43748 9.01838 4.43744 8.71862 4.25251 8.53376C4.16377 8.44504 4.0434 8.39518 3.91791 8.39515H1.74685C1.48539 8.39515 1.27344 8.60711 1.27344 8.86857V11.0397C1.2735 11.3011 1.4855 11.513 1.74696 11.513C1.87245 11.513 1.99282 11.4631 2.08156 11.3744L2.697 10.7589C5.04342 12.8513 8.64175 12.6453 10.7341 10.2989C11.4757 9.46725 11.9569 8.43628 12.118 7.33376C12.1818 6.94308 11.9169 6.57463 11.5262 6.51081C11.4908 6.50502 11.4551 6.50189 11.4193 6.50146Z"
                            fill="#064771"
                          />
                        </svg>

                        <button
                          className="text-[#064771] text-[12px] text-nowrap"
                          onClick={() => {
                         
                          navigate(`/partner-portal/edit/${id}`);
                          }}
                        >
                          Update
                        </button>
                      </div>
                    </button>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Right Banner Div End */}
      </div>
      {/* Top Header div End */}

      {/* Folder Section Start */}

      <FileManager
        fetchFolders={fetchFoldersApi}
        createFolder={createFolderApi}
        renameFolder={renameFolderApi}
        deleteFolder={deleteFolderApi}
        // onCopyLink={handleCopyLinkExample}
        // onDownload={handleDownloadExample}
        // onShare={handleShareExample}
        // onViewSize={handleViewSizeExample}
        // onFolderSelect={handleFolderSelected}
        // initialLoading={true}
      />

      {/* Folder Section End */}

      {/* Files Section Start */}
      <div className="flex self-stretch justify-start items-start flex-col gap-4 mt-[42px] ">
        <div className="flex justify-start items-center flex-row gap-4">
          <span className="text-[#0C5577] text-lg font-medium leading-5">
            Files
          </span>
        </div>
        <svg
          width="1316"
          height="2"
          viewBox="0 0 1316 2"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path d="M0.5 1H1315.5" stroke="#BCC2C5" />
        </svg>

        {/* The table Content will be added here */}
      </div>
      {/* Files Section End */}

      {/* The button div start*/}
      <div className="ml-7 mt-[110px]">
        {/* The footer button start */}

        <div className="flex justify-between items-center flex-row gap-[916px] mt-15 ml-">
          <div
            className="flex justify-start items-end flex-row gap-[10.06532096862793px] w-[93px] h-[34px]"
            style={{ width: "93px" }}
          ></div>

          <div className="flex justify-start items-center flex-row gap-4 mx-auto w-fit ml-[-350px]">
            {/* Back Button */}

            <button className="flex justify-center items-center flex-row gap-1.5 py-[5.032660484313965px] px-3 bg-[#064771] rounded-[49.82036209106445px] h-[34px] ">
              <svg
                width="8"
                height="14"
                viewBox="0 0 8 14"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M7.71748 12.3618C8.09417 12.7366 8.09417 13.3443 7.71748 13.7191C7.34078 14.0939 6.73003 14.0939 6.35333 13.7191L0.282264 7.67829C-0.0940858 7.30381 -0.0940857 6.69667 0.282264 6.32219L6.35334 0.28136C6.73003 -0.0934614 7.34078 -0.0934612 7.71748 0.281361C8.09418 0.656182 8.09418 1.26389 7.71748 1.63871L2.32911 7.00024L7.71748 12.3618Z"
                  fill="white"
                />
              </svg>

              <span className="text-[#FFF] ">Back</span>
            </button>

            {/* The save as draft button */}

            {/* The save and next button */}
            <div className="flex justify-start items-end flex-row gap-[10.06532096862793px] h-[34px]">
              <button className="flex justify-center items-center flex-row gap-1.5 py-[5.032660484313965px] px-3 bg-[#064771] rounded-[49.82036209106445px] h-[34px]">
                <span className="text-[#FFF] ">Next</span>

                <svg
                  width="8"
                  height="14"
                  viewBox="0 0 8 14"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M0.282523 1.63847C-0.0941745 1.26364 -0.0941745 0.655938 0.282523 0.281116C0.659221 -0.0937055 1.26997 -0.0937055 1.64667 0.281116L7.71774 6.32195C8.09409 6.69643 8.09409 7.30357 7.71774 7.67805L1.64667 13.7189C1.26997 14.0937 0.659221 14.0937 0.282523 13.7189C-0.0941745 13.3441 -0.0941745 12.7364 0.282523 12.3615L5.67089 7L0.282523 1.63847Z"
                    fill="white"
                  />
                </svg>
              </button>
            </div>
          </div>
        </div>

        {/* The footer button end */}
      </div>
      {/* The Button div end */}
    </div>

    // Main div end
  );
};

export default Attachments;

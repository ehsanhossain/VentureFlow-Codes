import React, { useState, useMemo } from "react";

import Pagination from "../../../components/pagination";
import ArrowIcon from "../../../assets/svg/ArrowIcon";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../../../components/table/table";

// const breadcrumbLinks = [
//   { label: "Home", url: "/", isCurrentPage: false },
//   { label: "Currency Management", url: "", isCurrentPage: true },
// ];

const SharedBuyers = (): JSX.Element => {
  const tableHeaders = [
    "No",
    "Sellers Name",
    "Country Preference",
    "Industry Pref.",
    "EBITDA Pref.",
    "Investment Range",
    "Dealroom",
    "Quick Actions",
  ];

  const partnerData = useMemo(
    () => [
      {
        no: "01",

        seller_name: "¥ 3.5B ~ ¥ 5.5B",
        countryFlag: "/group-291565.png",
        country_pref: "Italy",
        industry_pref: "Wholesale",
        ebitda_pref: "Wholesale",
        investment_range: "₺110M",

        dealroom: "GR-S-675",

        quickActions: "Active",
      },
    ],
    []
  );

  const [sortConfig, setSortConfig] = useState<{
    key: keyof (typeof partnerData)[0];
    direction: "asc" | "desc";
  } | null>(null);

  const sortedPartnerData = useMemo(() => {
    if (!sortConfig) return partnerData;

    return [...partnerData].sort((a, b) => {
      const aValue = a[sortConfig.key];
      const bValue = b[sortConfig.key];

      if (sortConfig.key === "exchangeRate") {
        const parse = (val: string) => parseFloat(val.replace(/[^0-9.]/g, ""));
        return sortConfig.direction === "asc"
          ? parse(aValue as string) - parse(bValue as string)
          : parse(bValue as string) - parse(aValue as string);
      }

      if (typeof aValue === "string" && typeof bValue === "string") {
        return sortConfig.direction === "asc"
          ? aValue.localeCompare(bValue)
          : bValue.localeCompare(aValue);
      }

      return 0;
    });
  }, [sortConfig, partnerData]);

  const handleSort = (key: keyof (typeof partnerData)[0]) => {
    setSortConfig((prev) =>
      prev?.key === key
        ? { key, direction: prev.direction === "asc" ? "desc" : "asc" }
        : { key, direction: "asc" }
    );
  };
  //   const [isActive, setIsActive] = useState(false);
  return (
    <div>
      <section className="flex flex-col gap-3.5 w-full px-8 mt-[15px]">
        <div className="w-full">
          <Table className="w-full border-separate border-spacing-y-[10px]">
            <TableHeader>
              <TableRow className="rounded-lg">
                {tableHeaders.map((header, idx) => {
                  const key = Object.keys(partnerData[0])[idx] as
                    | keyof (typeof partnerData)[0]
                    | undefined;

                  return (
                    <TableHead
                      key={idx}
                      onClick={() => key && handleSort(key)}
                      className={`cursor-pointer py-[10px] px-6 font-semibold text-[#727272] text-sm border-t border-b ${
                        idx === 0 ? "border-l first:rounded-l-lg" : ""
                      } ${
                        idx === tableHeaders.length - 1
                          ? "border-r last:rounded-r-lg"
                          : ""
                      } bg-[#F9F9F9] text-center whitespace-nowrap hover:bg-[#d1d1d1] transition-colors`}
                    >
                      <div className="flex items-center justify-center gap-2">
                        {header}
                        <ArrowIcon />
                      </div>
                    </TableHead>
                  );
                })}
              </TableRow>
            </TableHeader>

            <TableBody>
              {sortedPartnerData.map((partner, index) => (
                <TableRow key={index}>
                  <TableCell className="py-[10px] px-6 font-semibold text-[#30313D] text-sm border-t border-b border-l border-[#E4E4E4] bg-white rounded-l-lg truncate whitespace-nowrap">
                    <div className="ml-[30px]">{partner.no}</div>
                  </TableCell>

                  <TableCell className="py-[10px] px-6 text-center text-[#30313D] text-sm border-t border-b border-[#E4E4E4] bg-white truncate whitespace-nowrap">
                    {partner.seller_name}
                  </TableCell>

                  <TableCell className="py-[10px] px-6 text-center font-medium text-[#30313D] text-sm border-t border-b border-[#E4E4E4] bg-white truncate whitespace-nowrap">
                    <div className="flex items-center justify-center gap-3">
                      <img
                        className="w-[26px] h-[26px] rounded-full"
                        alt={`${partner.country_pref} flag`}
                        src={partner.countryFlag}
                      />
                      <span>{partner.country_pref}</span>
                    </div>
                  </TableCell>

                  <TableCell className="py-[10px] px-6 text-center text-[#30313D] text-sm border-t border-b border-[#E4E4E4] bg-white truncate whitespace-nowrap">
                    {partner.industry_pref}
                  </TableCell>

                  <TableCell className="py-[10px] px-6 text-center text-[#30313D] text-sm border-t border-b border-[#E4E4E4] bg-white truncate whitespace-nowrap">
                    {partner.ebitda_pref}
                  </TableCell>

                  <TableCell className="py-[10px] px-6 text-center text-[#30313D] text-sm border-t border-b border-[#E4E4E4] bg-white truncate whitespace-nowrap">
                    {partner.investment_range}
                  </TableCell>

                  <TableCell className="py-[10px] px-6 text-center text-[#064771] text-sm border-t border-b border-[#E4E4E4] bg-white truncate whitespace-nowrap underline">
                    {partner.dealroom}
                  </TableCell>

                  <TableCell className="py-2 px-6 text-center border-t border-b border-r border-[#E4E4E4] bg-white rounded-r-lg whitespace-nowrap ">
                    <div className="flex items-center justify-center gap-3">
                      {/* First Button - Red Border with Trash Icon */}
                      <button
                        type="button"
                        className="flex items-center justify-center w-[35px] h-[35px] bg-[#FFF7F7] border rounded-full p-1"
                      >
                        <svg
                          width="21"
                          height="16"
                          viewBox="0 0 21 16"
                          fill="none"
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path
                            d="M19.7781 5.79048C18.5013 3.62804 15.5969 0 10.4995 0C5.40213 0 2.4978 3.62804 1.22098 5.79048C0.826265 6.45437 0.617188 7.21947 0.617188 8C0.617187 8.78053 0.826265 9.54564 1.22098 10.2095C2.4978 12.372 5.40213 16 10.4995 16C15.5969 16 18.5013 12.372 19.7781 10.2095C20.1728 9.54564 20.3819 8.78053 20.3819 8C20.3819 7.21947 20.1728 6.45437 19.7781 5.79048ZM18.3745 9.31322C17.278 11.1675 14.7959 14.2879 10.4995 14.2879C6.20313 14.2879 3.72111 11.1675 2.62458 9.31322C2.39007 8.91861 2.26586 8.46388 2.26586 8C2.26586 7.53612 2.39007 7.0814 2.62458 6.68678C3.72111 4.83253 6.20313 1.71215 10.4995 1.71215C14.7959 1.71215 17.278 4.82911 18.3745 6.68678C18.609 7.0814 18.7332 7.53612 18.7332 8C18.7332 8.46388 18.609 8.91861 18.3745 9.31322Z"
                            fill="#064771"
                          />
                          <path
                            d="M10.5009 3.76465C9.66326 3.76465 8.84441 4.01304 8.14792 4.47842C7.45143 4.9438 6.90858 5.60527 6.58802 6.37917C6.26746 7.15306 6.18359 8.00464 6.34701 8.82621C6.51043 9.64777 6.9138 10.4024 7.50612 10.9947C8.09843 11.5871 8.85309 11.9904 9.67466 12.1539C10.4962 12.3173 11.3478 12.2334 12.1217 11.9128C12.8956 11.5923 13.5571 11.0494 14.0224 10.3529C14.4878 9.65645 14.7362 8.8376 14.7362 7.99994C14.7349 6.87708 14.2882 5.8006 13.4942 5.00662C12.7003 4.21264 11.6238 3.76599 10.5009 3.76465ZM10.5009 10.5411C9.99832 10.5411 9.50701 10.3921 9.08912 10.1129C8.67122 9.83362 8.34552 9.43675 8.15318 8.97241C7.96084 8.50807 7.91052 7.99712 8.00857 7.50418C8.10662 7.01124 8.34865 6.55845 8.70404 6.20306C9.05943 5.84767 9.51222 5.60565 10.0052 5.50759C10.4981 5.40954 11.009 5.45987 11.4734 5.6522C11.9377 5.84454 12.3346 6.17025 12.6138 6.58814C12.8931 7.00603 13.0421 7.49734 13.0421 7.99994C13.0421 8.6739 12.7744 9.32026 12.2978 9.79682C11.8212 10.2734 11.1749 10.5411 10.5009 10.5411Z"
                            fill="#064771"
                          />
                        </svg>
                      </button>

                      {/* Second Button - Blue Border with Eye Icon */}
                      <button
                        type="button"
                        className="flex items-center justify-center w-[35px] h-[35px] bg-white"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="5"
                          height="17"
                          viewBox="0 0 5 17"
                          fill="none"
                        >
                          <path
                            d="M2.50244 12.0251C1.35175 12.0251 0.418933 12.9545 0.418933 14.1009C0.418933 15.2474 1.35175 16.1768 2.50244 16.1768C3.65312 16.1768 4.58594 15.2474 4.58594 14.1009C4.58594 12.9545 3.65312 12.0251 2.50244 12.0251Z"
                            fill="#54575C"
                          />
                          <path
                            d="M2.50244 6.62669C1.35175 6.62669 0.418933 7.55607 0.418933 8.70251C0.418933 9.84895 1.35175 10.7783 2.50244 10.7783C3.65312 10.7783 4.58594 9.84895 4.58594 8.70251C4.58594 7.55607 3.65312 6.62669 2.50244 6.62669Z"
                            fill="#54575C"
                          />
                          <path
                            d="M2.50244 0.822005C1.35175 0.822006 0.418933 1.75138 0.418933 2.89782C0.418933 4.04426 1.35175 4.97363 2.50244 4.97363C3.65312 4.97363 4.58594 4.04426 4.58594 2.89782C4.58594 1.75138 3.65312 0.822005 2.50244 0.822005Z"
                            fill="#54575C"
                          />
                        </svg>
                      </button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </section>

      <Pagination />
    </div>
    // Main div start

    // Main div end
  );
};

export default SharedBuyers;
